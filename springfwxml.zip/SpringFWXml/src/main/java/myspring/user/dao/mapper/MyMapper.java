package myspring.user.dao.mapper;

public @interface MyMapper {
}
